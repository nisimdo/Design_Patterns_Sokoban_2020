﻿using System;

namespace Sokoban.Infrastructure
{
    public class Class1
    {
    }
}